import discord
# asks you which game
async def gameslist(ctx, bot):
    embed= discord.Embed(
        title="Please choose a game",
        description="1: Tic Tac Toe \n2: Rock Paper Scissors"
    )
    #reacts so you can choose the games
    await ctx.channel.purge(limit=1)
    msg = await ctx.send(embed=embed)
    await msg.add_reaction("1️⃣")
    await msg.add_reaction("2️⃣")
    # checks for which game you chose
    def checkreaction(reaction, user):
        return user != bot.user and(str(reaction.emoji) == "1️⃣" or str(reaction.emoji) == "2️⃣")

    reaction, user = await bot.wait_for("reaction_add", timeout=30.0, check=checkreaction)

    if str(reaction.emoji) == "1️⃣":
            game = "ttt"
            await botorai(bot, ctx, game)
            pass
    if str(reaction.emoji) == "2️⃣":
            game="rps"
            await botorai(bot, ctx, game)
            pass
# asks if you want to play the bot or ai
async def botorai(bot, ctx, game):
        embed= discord.Embed(
            title= "Do you want to play another member or the AI?",
            description="1: Another member \n2: AI"
        )
        # reacts so you can choose
        msg = await ctx.send(embed=embed)
        await msg.add_reaction("1️⃣")
        await msg.add_reaction("2️⃣")

        def checkreactions(reaction, user):
            return user != bot.user and(str(reaction.emoji) == "1️⃣" or str(reaction.emoji) == "2️⃣")

        reaction, user = await bot.wait_for("reaction_add", timeout=30.0, check=checkreactions)

        if str(reaction.emoji) == "1️⃣":
            opponent = "human"
            await ttt(ctx, bot, opponent, game)
            pass
        if str(reaction.emoji) == "2️⃣":
            opponent = "ai"
            await ttt(ctx, bot, opponent, game)
            pass
        
# code for tictactoe
async def ttt(ctx, bot, opponent, game):
    if game == "ttt":
        if opponent == "human":
            # if you are playing human it gets bth of your emojis
                async def gettingplayer1():
                    if opponent == "human":
                        global player_1
                        await ctx.send("Player 1 please react to this message with your emoji!")
                        def checkplayer1(reaction, user):
                                return user != bot.user
                        reaction, user = await bot.wait_for("reaction_add", timeout=30.0, check=checkplayer1)
                        player_1 = reaction.emoji
                        return str(reaction.emoji)
                async def gettingplayer2():
                    if opponent == "human":
                        global player_2
                        await ctx.send("Player 2 please react to this message with your emoji!")
                        def checkplayer2(reaction, user):
                                return user != bot.user
                        reaction, user = await bot.wait_for("reaction_add", timeout=30.0, check=checkplayer2)
                        player_2 = reaction.emoji
                        return str(reaction.emoji)
                await gettingplayer1()
                await gettingplayer2()
                #tells you the emojis you picked
                await ctx.send("Player 1: " + str(player_1) + "\nPlayer 2: " + str(player_2))
        
        if opponent == "ai":
            # if you are playing ai it gets your emoji
            async def gettingplayer():
                global aipfp
                global player1vsai
                aipfp = "🤖"
                await ctx.send("Please react to this message with your emoji!")
                def checkplayer1(reaction, user):
                        return user != bot.user
                reaction, user = await bot.wait_for("reaction_add", timeout=30.0, check=checkplayer1)
                player1vsai = reaction.emoji
                return str(reaction.emoji)
            await gettingplayer()
            await ctx.send("You are: " + str(player1vsai) + "\nAI is: " + aipfp)
            
