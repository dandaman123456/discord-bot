import discord
import random
from gamemenu import *

async def ttt(ctx, bot, opponent):
    if opponent == "human":
        print("got this far")
        async def gettingcharacters():
            if opponent == True:
                player = 1
                await ctx.send("Player " + str(player) + " please react to this message with your emoji!")

                def checkplayers(user, player):
                    return user != bot.user

                reaction, user = await bot.wait_for("reaction_add", timeout=30.0, check=checkplayers)
                player = +1
                return str(reaction.emoji)
            
            player_1 = await gettingcharacters(ctx, bot, player)
            ctx.send (f"Player 1 {player_1}")
                
            
        
    

