import discord
from discord.ext import commands
from config import *
from gamemenu import *

bot = commands.Bot(command_prefix=prefix, description="The Official ItzMeStevo Bot!")

# says bot is online when the bot is run
@bot.event
async def on_ready():
    print("I am Online")


# response to ;hello
@bot.command(pass_context=True)
async def hello(ctx, name: str):
    if name == "ItzMeStevo":
        await ctx.send(f"Hi there the great master! {name}")
    else:
        await ctx.send(f"Hi there! {name}")

#clears chat when run eg. clear 1 will clear 1 message
@bot.command(pass_context=True)
async def clear(ctx, amount:str):
    if amount == "all":
        await ctx.channel.purge()
    else:
        await ctx.channel.purge(limit=(int(amount) + 1))

# embeds download link to money addon when ;download is run
@bot.command(pass_context=True)
async def download(ctx):
    embed = discord.Embed(
        title="Click here to download",
        url="https://linkvertise.com/381338/moneyaddon-by-itzmestevo/1"
    )
    await ctx.send(embed=embed)

#runs the game list in gamemenu.py
@bot.command(pass_context=True)
async def games(ctx):
    await gameslist(ctx, bot)

#runs the bot
bot.run(token, bot=True, reconnect=True)