token = "OTg1MTA4ODU5MDQ1Njc5MTA0.GEWUza.17rKJZ-NOiiP2G9rPJLdXT6_VfUMdPVhdV4REM"
prefix = ";"
# self explanitory